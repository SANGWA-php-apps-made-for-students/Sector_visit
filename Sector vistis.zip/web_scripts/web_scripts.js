//<editor-fold defaultstate="collapsed" desc="these variables are used in the delete and update of the table records">
var table_update = '';
var id_delete = 0;
var current_del_btn = null;
//</editor-fold>
$(document).ready(function () {
get_new_data_hide_show();
show_form_toUpdate();
request_del_udpate();
get_pages_moving();
dlog_btn_No_Yes();
hide_select_pane()
show_Y_N_dialog();
hide_Y_N_dialog()

        get_account_category_id_combo();        get_profile_id_combo();        get_image_id_combo();        get_account_id_combo();        get_cell_id_combo();        get_account_id_combo();        get_cell_id_combo();        get_account_id_combo();        get_account_id_combo();        get_visit_id_combo();        get_comment_id_combo();        get_account_id_combo();        get_account_id_combo();        get_profile_id_combo();        get_account_id_combo();        get_schedule_id_combo();        get_worker_id_combo();        get_user_id_combo();


});

function get_account_category_id_combo() {
    try {
        $('.cbo_account_category').change(function () {
            var cbo_account_category = $('.cbo_account_category option:selected').val();
                $('#txt_account_category_id').val(cbo_account_category);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').val();
                $('#txt_profile_id').val(cbo_profile);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_image_id_combo() {
    try {
        $('.cbo_image').change(function () {
            var cbo_image = $('.cbo_image option:selected').val();
                $('#txt_image_id').val(cbo_image);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_cell_id_combo() {
    try {
        $('.cbo_cell').change(function () {
            var cbo_cell = $('.cbo_cell option:selected').val();
                $('#txt_cell_id').val(cbo_cell);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_cell_id_combo() {
    try {
        $('.cbo_cell').change(function () {
            var cbo_cell = $('.cbo_cell option:selected').val();
                $('#txt_cell_id').val(cbo_cell);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_visit_id_combo() {
    try {
        $('.cbo_visit').change(function () {
            var cbo_visit = $('.cbo_visit option:selected').val();
                $('#txt_visit_id').val(cbo_visit);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_comment_id_combo() {
    try {
        $('.cbo_comment').change(function () {
            var cbo_comment = $('.cbo_comment option:selected').val();
                $('#txt_comment_id').val(cbo_comment);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').val();
                $('#txt_profile_id').val(cbo_profile);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_schedule_id_combo() {
    try {
        $('.cbo_schedule').change(function () {
            var cbo_schedule = $('.cbo_schedule option:selected').val();
                $('#txt_schedule_id').val(cbo_schedule);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_worker_id_combo() {
    try {
        $('.cbo_worker').change(function () {
            var cbo_worker = $('.cbo_worker option:selected').val();
                $('#txt_worker_id').val(cbo_worker);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}
function cancel_update() {
    $('.cancel_btn').unbind('click').click(function () {
        var cancel_update = $(this).data('cancel_name');
        $.post('../admin/handler.php', {cancel_update: cancel_update}, function (data) {
        }).complete(function () {
            window.location.reload();
        });
    });
}
function hide_Y_N_dialog() {//here the user will be confirming to delete the record
    $('#user_yes_btn,  .yes_dlg_btn').click(function () {
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {

        }).complete(function () {
            $('.y_n_dialog').fadeOut(300);
            current_del_btn.closest('tr').slideUp(400);
            $('.menu').show();
            window.location.reload();
        });
    });
    $('#no_btn, .no_btn').click(function () {
        $('.y_n_dialog').fadeOut(300);
        $('.menu').show();
    });

}function show_Y_N_dialog() {
    $('.y_n_dialog').fadeIn(200);
}
function get_new_data_hide_show(){
     $('.new_data_hider').click(function (){
         $('.new_data_box').slideToggle();
     });
    
}
function validate_numbers_textfields() {
  $('.only_numbers').keydown(function (e) {
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                        // Allow: Ctrl+A, Command+A
                                (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                                // Allow: home, end, left, right, down, up
                                        (e.keyCode >= 35 && e.keyCode <= 40)) {
                            // let it happen, don't do anything
                            return;
                        }
                        // Ensure that it is a number and stop the keypress
                        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                            e.preventDefault();
                        }
                    });   }
function hover_theme1() {
    $('.hover_theme1').mouseover(function () {
        $(this).css('background-color', '#29f15c');
        $(this).addClass('no_shade_noBorder');
        $(this).css('cursoer','pointer');
    });

    $('.hover_theme1').mouseleave(function () {
        $(this).css('background-color', 'transparent');
        $(this).removeClass('no_shade_noBorder');
    });
}
function show_form_toUpdate() {
    var updname=$('#txt_shall_expand_toUpdate').val();
    if (updname!='') {
          $('.new_data_box').delay(200).slideDown();
    }
        
}
function postDisplayData(call_dialog,div) {
    $.post('../Admin/handler.php', {call_dialog: call_dialog}, function (data) {
        $(div).html(data);
    }).complete(function () {
        $('.msg_dialog').slideDown(300);
    });
}function dlog_btn_No_Yes() {
    $('#dlog_btnNo').unbind('click').click(function () {
        alert('Confirmed!');
    });
    $('#dlog_btnYs').unbind('click').click(function () {
         alert('Declined!');
    });
}function hide_select_pane() {
    $('.foreign_select').unbind('click').click(function () {
        $(this).fadeOut(200);
        $('.dialog').hide("drop", {direction: 'up'}, 500,
                (function () {
                    $('.menu').show();
                }));
    });

}

//update from account ...
 
function account_del_udpate(){
$('.account_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount.. 
 $('.account_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from account_category ...
 
function account_category_del_udpate(){
$('.account_category_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account_category').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount_category.. 
 $('.account_category_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from profile ...
 
function profile_del_udpate(){
$('.profile_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.profile').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprofile.. 
 $('.profile_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from image ...
 
function image_del_udpate(){
$('.image_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.image').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromimage.. 
 $('.image_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from schedule_cell ...
 
function schedule_cell_del_udpate(){
$('.schedule_cell_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.schedule_cell').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromschedule_cell.. 
 $('.schedule_cell_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from niboye_schedule ...
 
function niboye_schedule_del_udpate(){
$('.niboye_schedule_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.niboye_schedule').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromniboye_schedule.. 
 $('.niboye_schedule_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cell_worker ...
 
function cell_worker_del_udpate(){
$('.cell_worker_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cell_worker').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcell_worker.. 
 $('.cell_worker_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from niboye_worker ...
 
function niboye_worker_del_udpate(){
$('.niboye_worker_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.niboye_worker').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromniboye_worker.. 
 $('.niboye_worker_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from comments ...
 
function comments_del_udpate(){
$('.comments_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.comments').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcomments.. 
 $('.comments_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from com_replies ...
 
function com_replies_del_udpate(){
$('.com_replies_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.com_replies').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcom_replies.. 
 $('.com_replies_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from site_visits ...
 
function site_visits_del_udpate(){
$('.site_visits_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.site_visits').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromsite_visits.. 
 $('.site_visits_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from pub_comments ...
 
function pub_comments_del_udpate(){
$('.pub_comments_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.pub_comments').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete frompub_comments.. 
 $('.pub_comments_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from workers ...
 
function workers_del_udpate(){
$('.workers_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.workers').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromworkers.. 
 $('.workers_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cell ...
 
function cell_del_udpate(){
$('.cell_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cell').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcell.. 
 $('.cell_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from o_schedule ...
 
function o_schedule_del_udpate(){
$('.o_schedule_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.o_schedule').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromo_schedule.. 
 $('.o_schedule_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from o_worker_schedule ...
 
function o_worker_schedule_del_udpate(){
$('.o_worker_schedule_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.o_worker_schedule').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromo_worker_schedule.. 
 $('.o_worker_schedule_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from request ...
 
function request_del_udpate(){
$('.request_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.request').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromrequest.. 
 $('.request_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
