<?php
 session_start();

if (isset($_POST['cbo_account_category'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
    return $id;
}
if (isset($_POST['cbo_profile'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
    return $id;
}
if (isset($_POST['cbo_image'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_image_id_by_image_name($_POST['cbo_image']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_cell'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_cell_id_by_cell_name($_POST['cbo_cell']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_cell'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_cell_id_by_cell_name($_POST['cbo_cell']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_visit'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_visit_id_by_visit_name($_POST['cbo_visit']);
    return $id;
}
if (isset($_POST['cbo_comment'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_comment_id_by_comment_name($_POST['cbo_comment']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_profile'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_schedule'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_schedule_id_by_schedule_name($_POST['cbo_schedule']);
    return $id;
}
if (isset($_POST['cbo_worker'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_worker_id_by_worker_name($_POST['cbo_worker']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}

if (isset($_POST['table_to_update']) ) {
    $id_upd = $_POST['id_update'];
    $table_upd = $_POST['table_to_update'];
    $pref = 'upd_';
    $sufx = $table_upd;
    $_SESSION['table_to_update'] = $table_upd;
    $_SESSION['id_upd'] = $id_upd;
    echo $_SESSION['id_upd'];
}


//The Delete from account
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account($id);}
//The Delete from account_category
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account_category') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account_category($id);}
//The Delete from profile
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'profile') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_profile($id);}
//The Delete from image
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'image') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_image($id);}
//The Delete from schedule_cell
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'schedule_cell') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_schedule_cell($id);}
//The Delete from niboye_schedule
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'niboye_schedule') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_niboye_schedule($id);}
//The Delete from cell_worker
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cell_worker') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cell_worker($id);}
//The Delete from niboye_worker
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'niboye_worker') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_niboye_worker($id);}
//The Delete from comments
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'comments') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_comments($id);}
//The Delete from com_replies
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'com_replies') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_com_replies($id);}
//The Delete from site_visits
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'site_visits') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_site_visits($id);}
//The Delete from pub_comments
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'pub_comments') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_pub_comments($id);}
//The Delete from workers
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'workers') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_workers($id);}
//The Delete from cell
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cell') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cell($id);}
//The Delete from o_schedule
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'o_schedule') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_o_schedule($id);}
//The Delete from o_worker_schedule
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'o_worker_schedule') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_o_worker_schedule($id);}
//The Delete from request
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'request') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_request($id);}
if (isset($_POST['pagination_n'])) {
    $_SESSION['pagination_n'] = $_POST['pagination_n'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['paginated_page'];
}
if (isset($_POST['page_no_iteml'])) {
    unset($_SESSION['pagination_n']);
    $_SESSION['page_no_iteml'] = $_POST['page_no_iteml'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['page_no_iteml'];
}
