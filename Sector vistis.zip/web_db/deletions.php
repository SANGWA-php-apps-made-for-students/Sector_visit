<?php 
require_once 'connection.php';
class deletions{


 function deleteFrom_account( $account_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM account where account_id =:account_id");
$smt->bindValue(':account_id',$account_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_account_category( $account_category_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM account_category where account_category_id =:account_category_id");
$smt->bindValue(':account_category_id',$account_category_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_profile( $profile_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM profile where profile_id =:profile_id");
$smt->bindValue(':profile_id',$profile_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_image( $image_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM image where image_id =:image_id");
$smt->bindValue(':image_id',$image_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_schedule_cell( $schedule_cell_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM schedule_cell where schedule_cell_id =:schedule_cell_id");
$smt->bindValue(':schedule_cell_id',$schedule_cell_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_niboye_schedule( $niboye_schedule_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM niboye_schedule where niboye_schedule_id =:niboye_schedule_id");
$smt->bindValue(':niboye_schedule_id',$niboye_schedule_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cell_worker( $cell_worker_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cell_worker where cell_worker_id =:cell_worker_id");
$smt->bindValue(':cell_worker_id',$cell_worker_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_niboye_worker( $niboye_worker_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM niboye_worker where niboye_worker_id =:niboye_worker_id");
$smt->bindValue(':niboye_worker_id',$niboye_worker_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_comments( $comments_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM comments where comments_id =:comments_id");
$smt->bindValue(':comments_id',$comments_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_com_replies( $com_replies_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM com_replies where com_replies_id =:com_replies_id");
$smt->bindValue(':com_replies_id',$com_replies_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_site_visits( $site_visits_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM site_visits where site_visits_id =:site_visits_id");
$smt->bindValue(':site_visits_id',$site_visits_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_pub_comments( $pub_comments_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM pub_comments where pub_comments_id =:pub_comments_id");
$smt->bindValue(':pub_comments_id',$pub_comments_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_workers( $workers_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM workers where workers_id =:workers_id");
$smt->bindValue(':workers_id',$workers_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cell( $cell_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cell where cell_id =:cell_id");
$smt->bindValue(':cell_id',$cell_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_o_schedule( $o_schedule_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM o_schedule where o_schedule_id =:o_schedule_id");
$smt->bindValue(':o_schedule_id',$o_schedule_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_o_worker_schedule( $o_worker_schedule_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM o_worker_schedule where o_worker_schedule_id =:o_worker_schedule_id");
$smt->bindValue(':o_worker_schedule_id',$o_worker_schedule_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_request( $request_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM request where request_id =:request_id");
$smt->bindValue(':request_id',$request_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


}

