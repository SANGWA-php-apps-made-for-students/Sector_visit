<?php
 require_once '../web_db/connection.php'; 
class multi_values{


function list_account($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from account";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> account </td>
<td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td> Position </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['account_id']; ?>
</td>
<td class="account_category_id_cols account " title="account" >
<?php echo  $this->_e($row['account_category']); ?>
</td>
<td>
<?php echo  $this->_e($row['date_created']); ?>
</td>
<td>
<?php echo  $this->_e($row['profile']); ?>
</td>
<td>
<?php echo  $this->_e($row['username']); ?>
</td>
<td>
<?php echo  $this->_e($row['password']); ?>
</td>
<td>
<?php echo  $this->_e($row['is_online']); ?>
</td>
<td>
<?php echo  $this->_e($row['position']); ?>
</td>


<td>
                        <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="account_id"  data-table="
                           <?php echo $row['account_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="account_update_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_account_account_category($id) {
        
        $db = new dbconnection();
        $sql = "select   account.account_category from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account_category'];
        echo $field;
    } function get_chosen_account_date_created($id) {
        
        $db = new dbconnection();
        $sql = "select   account.date_created from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date_created'];
        echo $field;
    } function get_chosen_account_profile($id) {
        
        $db = new dbconnection();
        $sql = "select   account.profile from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    } function get_chosen_account_username($id) {
        
        $db = new dbconnection();
        $sql = "select   account.username from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['username'];
        echo $field;
    } function get_chosen_account_password($id) {
        
        $db = new dbconnection();
        $sql = "select   account.password from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['password'];
        echo $field;
    } function get_chosen_account_is_online($id) {
        
        $db = new dbconnection();
        $sql = "select   account.is_online from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['is_online'];
        echo $field;
    } function get_chosen_account_position($id) {
        
        $db = new dbconnection();
        $sql = "select   account.position from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['position'];
        echo $field;
    }

 function All_account() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  account_id   from account";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }
 function get_last_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }
function list_account_category($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from account_category";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> account_category </td>
<td>  </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['account_category_id']; ?>
</td>
<td class="name_id_cols account_category " title="account_category" >
<?php echo  $this->_e($row['name']); ?>
</td>


<td>
                        <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="account_category_id"  data-table="
                           <?php echo $row['account_category_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="account_category_update_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_account_category_name($id) {
        
        $db = new dbconnection();
        $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_category_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

 function All_account_category() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  account_category_id   from account_category";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_account_category() {
        $con = new dbconnection();
        $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_category_id'];
        return $first_rec;
    }
 function get_last_account_category() {
        $con = new dbconnection();
        $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_category_id'];
        return $first_rec;
    }
function list_profile($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from profile";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> profile </td>
<td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td> Entry Date </td><td> User </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['profile_id']; ?>
</td>
<td class="dob_id_cols profile " title="profile" >
<?php echo  $this->_e($row['dob']); ?>
</td>
<td>
<?php echo  $this->_e($row['name']); ?>
</td>
<td>
<?php echo  $this->_e($row['last_name']); ?>
</td>
<td>
<?php echo  $this->_e($row['gender']); ?>
</td>
<td>
<?php echo  $this->_e($row['telephone_number']); ?>
</td>
<td>
<?php echo  $this->_e($row['email']); ?>
</td>
<td>
<?php echo  $this->_e($row['residence']); ?>
</td>
<td>
<?php echo  $this->_e($row['image']); ?>
</td>
<td>
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['User']); ?>
</td>


<td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="profile_id"  data-table="
                           <?php echo $row['profile_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="profile_update_link" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_profile_dob($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.dob from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['dob'];
        echo $field;
    } function get_chosen_profile_name($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    } function get_chosen_profile_last_name($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['last_name'];
        echo $field;
    } function get_chosen_profile_gender($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.gender from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['gender'];
        echo $field;
    } function get_chosen_profile_telephone_number($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['telephone_number'];
        echo $field;
    } function get_chosen_profile_email($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.email from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['email'];
        echo $field;
    } function get_chosen_profile_residence($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.residence from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['residence'];
        echo $field;
    } function get_chosen_profile_image($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.image from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['image'];
        echo $field;
    } function get_chosen_profile_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.entry_date from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_profile_User($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.User from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    }

 function All_profile() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  profile_id   from profile";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }
 function get_last_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }
function list_image($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from image";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> image </td>
<td>  </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['image_id']; ?>
</td>
<td class="path_id_cols image " title="image" >
<?php echo  $this->_e($row['path']); ?>
</td>


<td>
                        <a href="#" class="image_delete_link" style="color: #000080;" data-id_delete="image_id"  data-table="
                           <?php echo $row['image_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="image_update_link" style="color: #000080;" value="
                           <?php echo $row['image_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_image_path($id) {
        
        $db = new dbconnection();
        $sql = "select   image.path from image where image_id=:image_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':image_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['path'];
        echo $field;
    }

 function All_image() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  image_id   from image";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_image() {
        $con = new dbconnection();
        $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['image_id'];
        return $first_rec;
    }
 function get_last_image() {
        $con = new dbconnection();
        $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['image_id'];
        return $first_rec;
    }
function list_schedule_cell($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from schedule_cell";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> schedule_cell </td>
<td> User </td><td> Cell </td><td> Day </td><td> Time </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['schedule_cell_id']; ?>
</td>
<td class="account_id_cols schedule_cell " title="schedule_cell" >
<?php echo  $this->_e($row['account']); ?>
</td>
<td>
<?php echo  $this->_e($row['cell']); ?>
</td>
<td>
<?php echo  $this->_e($row['day']); ?>
</td>
<td>
<?php echo  $this->_e($row['time']); ?>
</td>


<td>
                        <a href="#" class="schedule_cell_delete_link" style="color: #000080;" data-id_delete="schedule_cell_id"  data-table="
                           <?php echo $row['schedule_cell_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="schedule_cell_update_link" style="color: #000080;" value="
                           <?php echo $row['schedule_cell_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_schedule_cell_account($id) {
        
        $db = new dbconnection();
        $sql = "select   schedule_cell.account from schedule_cell where schedule_cell_id=:schedule_cell_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':schedule_cell_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    } function get_chosen_schedule_cell_cell($id) {
        
        $db = new dbconnection();
        $sql = "select   schedule_cell.cell from schedule_cell where schedule_cell_id=:schedule_cell_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':schedule_cell_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['cell'];
        echo $field;
    } function get_chosen_schedule_cell_day($id) {
        
        $db = new dbconnection();
        $sql = "select   schedule_cell.day from schedule_cell where schedule_cell_id=:schedule_cell_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':schedule_cell_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['day'];
        echo $field;
    } function get_chosen_schedule_cell_time($id) {
        
        $db = new dbconnection();
        $sql = "select   schedule_cell.time from schedule_cell where schedule_cell_id=:schedule_cell_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':schedule_cell_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['time'];
        echo $field;
    }

 function All_schedule_cell() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  schedule_cell_id   from schedule_cell";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_schedule_cell() {
        $con = new dbconnection();
        $sql = "select schedule_cell.schedule_cell_id from schedule_cell
                    order by schedule_cell.schedule_cell_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['schedule_cell_id'];
        return $first_rec;
    }
 function get_last_schedule_cell() {
        $con = new dbconnection();
        $sql = "select schedule_cell.schedule_cell_id from schedule_cell
                    order by schedule_cell.schedule_cell_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['schedule_cell_id'];
        return $first_rec;
    }
function list_niboye_schedule($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from niboye_schedule";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> niboye_schedule </td>
<td> Schedule Time </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['niboye_schedule_id']; ?>
</td>
<td class="sc_time_id_cols niboye_schedule " title="niboye_schedule" >
<?php echo  $this->_e($row['sc_time']); ?>
</td>


<td>
                        <a href="#" class="niboye_schedule_delete_link" style="color: #000080;" data-id_delete="niboye_schedule_id"  data-table="
                           <?php echo $row['niboye_schedule_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="niboye_schedule_update_link" style="color: #000080;" value="
                           <?php echo $row['niboye_schedule_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_niboye_schedule_sc_time($id) {
        
        $db = new dbconnection();
        $sql = "select   niboye_schedule.sc_time from niboye_schedule where niboye_schedule_id=:niboye_schedule_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':niboye_schedule_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['sc_time'];
        echo $field;
    }

 function All_niboye_schedule() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  niboye_schedule_id   from niboye_schedule";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_niboye_schedule() {
        $con = new dbconnection();
        $sql = "select niboye_schedule.niboye_schedule_id from niboye_schedule
                    order by niboye_schedule.niboye_schedule_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['niboye_schedule_id'];
        return $first_rec;
    }
 function get_last_niboye_schedule() {
        $con = new dbconnection();
        $sql = "select niboye_schedule.niboye_schedule_id from niboye_schedule
                    order by niboye_schedule.niboye_schedule_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['niboye_schedule_id'];
        return $first_rec;
    }
function list_cell_worker($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from cell_worker";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> cell_worker </td>
<td> User </td><td> Cell </td><td> Position </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['cell_worker_id']; ?>
</td>
<td class="account_id_cols cell_worker " title="cell_worker" >
<?php echo  $this->_e($row['account']); ?>
</td>
<td>
<?php echo  $this->_e($row['cell']); ?>
</td>
<td>
<?php echo  $this->_e($row['position']); ?>
</td>


<td>
                        <a href="#" class="cell_worker_delete_link" style="color: #000080;" data-id_delete="cell_worker_id"  data-table="
                           <?php echo $row['cell_worker_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="cell_worker_update_link" style="color: #000080;" value="
                           <?php echo $row['cell_worker_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_cell_worker_account($id) {
        
        $db = new dbconnection();
        $sql = "select   cell_worker.account from cell_worker where cell_worker_id=:cell_worker_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':cell_worker_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    } function get_chosen_cell_worker_cell($id) {
        
        $db = new dbconnection();
        $sql = "select   cell_worker.cell from cell_worker where cell_worker_id=:cell_worker_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':cell_worker_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['cell'];
        echo $field;
    } function get_chosen_cell_worker_position($id) {
        
        $db = new dbconnection();
        $sql = "select   cell_worker.position from cell_worker where cell_worker_id=:cell_worker_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':cell_worker_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['position'];
        echo $field;
    }

 function All_cell_worker() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  cell_worker_id   from cell_worker";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_cell_worker() {
        $con = new dbconnection();
        $sql = "select cell_worker.cell_worker_id from cell_worker
                    order by cell_worker.cell_worker_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['cell_worker_id'];
        return $first_rec;
    }
 function get_last_cell_worker() {
        $con = new dbconnection();
        $sql = "select cell_worker.cell_worker_id from cell_worker
                    order by cell_worker.cell_worker_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['cell_worker_id'];
        return $first_rec;
    }
function list_niboye_worker($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from niboye_worker";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> niboye_worker </td>
<td> Account </td><td> Position </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['niboye_worker_id']; ?>
</td>
<td class="account_id_cols niboye_worker " title="niboye_worker" >
<?php echo  $this->_e($row['account']); ?>
</td>
<td>
<?php echo  $this->_e($row['position']); ?>
</td>


<td>
                        <a href="#" class="niboye_worker_delete_link" style="color: #000080;" data-id_delete="niboye_worker_id"  data-table="
                           <?php echo $row['niboye_worker_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="niboye_worker_update_link" style="color: #000080;" value="
                           <?php echo $row['niboye_worker_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_niboye_worker_account($id) {
        
        $db = new dbconnection();
        $sql = "select   niboye_worker.account from niboye_worker where niboye_worker_id=:niboye_worker_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':niboye_worker_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    } function get_chosen_niboye_worker_position($id) {
        
        $db = new dbconnection();
        $sql = "select   niboye_worker.position from niboye_worker where niboye_worker_id=:niboye_worker_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':niboye_worker_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['position'];
        echo $field;
    }

 function All_niboye_worker() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  niboye_worker_id   from niboye_worker";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_niboye_worker() {
        $con = new dbconnection();
        $sql = "select niboye_worker.niboye_worker_id from niboye_worker
                    order by niboye_worker.niboye_worker_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['niboye_worker_id'];
        return $first_rec;
    }
 function get_last_niboye_worker() {
        $con = new dbconnection();
        $sql = "select niboye_worker.niboye_worker_id from niboye_worker
                    order by niboye_worker.niboye_worker_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['niboye_worker_id'];
        return $first_rec;
    }
function list_comments($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from comments";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> comments </td>
<td> Message </td><td> Date </td><td> User </td><td> Visit </td><td> Entry Date </td><td> User </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['comments_id']; ?>
</td>
<td class="mesasge_id_cols comments " title="comments" >
<?php echo  $this->_e($row['mesasge']); ?>
</td>
<td>
<?php echo  $this->_e($row['date']); ?>
</td>
<td>
<?php echo  $this->_e($row['account']); ?>
</td>
<td>
<?php echo  $this->_e($row['visit']); ?>
</td>
<td>
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['User']); ?>
</td>


<td>
                        <a href="#" class="comments_delete_link" style="color: #000080;" data-id_delete="comments_id"  data-table="
                           <?php echo $row['comments_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="comments_update_link" style="color: #000080;" value="
                           <?php echo $row['comments_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_comments_mesasge($id) {
        
        $db = new dbconnection();
        $sql = "select   comments.mesasge from comments where comments_id=:comments_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':comments_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['mesasge'];
        echo $field;
    } function get_chosen_comments_date($id) {
        
        $db = new dbconnection();
        $sql = "select   comments.date from comments where comments_id=:comments_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':comments_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date'];
        echo $field;
    } function get_chosen_comments_account($id) {
        
        $db = new dbconnection();
        $sql = "select   comments.account from comments where comments_id=:comments_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':comments_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    } function get_chosen_comments_visit($id) {
        
        $db = new dbconnection();
        $sql = "select   comments.visit from comments where comments_id=:comments_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':comments_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['visit'];
        echo $field;
    } function get_chosen_comments_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   comments.entry_date from comments where comments_id=:comments_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':comments_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_comments_User($id) {
        
        $db = new dbconnection();
        $sql = "select   comments.User from comments where comments_id=:comments_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':comments_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    }

 function All_comments() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  comments_id   from comments";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_comments() {
        $con = new dbconnection();
        $sql = "select comments.comments_id from comments
                    order by comments.comments_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['comments_id'];
        return $first_rec;
    }
 function get_last_comments() {
        $con = new dbconnection();
        $sql = "select comments.comments_id from comments
                    order by comments.comments_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['comments_id'];
        return $first_rec;
    }
function list_com_replies($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from com_replies";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> com_replies </td>
<td> Comment </td><td> Message </td><td> Date </td><td> User </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['com_replies_id']; ?>
</td>
<td class="comment_id_cols com_replies " title="com_replies" >
<?php echo  $this->_e($row['comment']); ?>
</td>
<td>
<?php echo  $this->_e($row['message']); ?>
</td>
<td>
<?php echo  $this->_e($row['date']); ?>
</td>
<td>
<?php echo  $this->_e($row['account']); ?>
</td>


<td>
                        <a href="#" class="com_replies_delete_link" style="color: #000080;" data-id_delete="com_replies_id"  data-table="
                           <?php echo $row['com_replies_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="com_replies_update_link" style="color: #000080;" value="
                           <?php echo $row['com_replies_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_com_replies_comment($id) {
        
        $db = new dbconnection();
        $sql = "select   com_replies.comment from com_replies where com_replies_id=:com_replies_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':com_replies_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['comment'];
        echo $field;
    } function get_chosen_com_replies_message($id) {
        
        $db = new dbconnection();
        $sql = "select   com_replies.message from com_replies where com_replies_id=:com_replies_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':com_replies_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['message'];
        echo $field;
    } function get_chosen_com_replies_date($id) {
        
        $db = new dbconnection();
        $sql = "select   com_replies.date from com_replies where com_replies_id=:com_replies_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':com_replies_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date'];
        echo $field;
    } function get_chosen_com_replies_account($id) {
        
        $db = new dbconnection();
        $sql = "select   com_replies.account from com_replies where com_replies_id=:com_replies_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':com_replies_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

 function All_com_replies() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  com_replies_id   from com_replies";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_com_replies() {
        $con = new dbconnection();
        $sql = "select com_replies.com_replies_id from com_replies
                    order by com_replies.com_replies_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['com_replies_id'];
        return $first_rec;
    }
 function get_last_com_replies() {
        $con = new dbconnection();
        $sql = "select com_replies.com_replies_id from com_replies
                    order by com_replies.com_replies_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['com_replies_id'];
        return $first_rec;
    }
function list_site_visits($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from site_visits";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> site_visits </td>
<td> Date </td><td> Activity </td><td> Description </td><td> Account </td><td> Activity Date </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['site_visits_id']; ?>
</td>
<td class="date_id_cols site_visits " title="site_visits" >
<?php echo  $this->_e($row['date']); ?>
</td>
<td>
<?php echo  $this->_e($row['activity']); ?>
</td>
<td>
<?php echo  $this->_e($row['description']); ?>
</td>
<td>
<?php echo  $this->_e($row['account']); ?>
</td>
<td>
<?php echo  $this->_e($row['activity_date']); ?>
</td>


<td>
                        <a href="#" class="site_visits_delete_link" style="color: #000080;" data-id_delete="site_visits_id"  data-table="
                           <?php echo $row['site_visits_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="site_visits_update_link" style="color: #000080;" value="
                           <?php echo $row['site_visits_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_site_visits_date($id) {
        
        $db = new dbconnection();
        $sql = "select   site_visits.date from site_visits where site_visits_id=:site_visits_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':site_visits_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date'];
        echo $field;
    } function get_chosen_site_visits_activity($id) {
        
        $db = new dbconnection();
        $sql = "select   site_visits.activity from site_visits where site_visits_id=:site_visits_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':site_visits_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['activity'];
        echo $field;
    } function get_chosen_site_visits_description($id) {
        
        $db = new dbconnection();
        $sql = "select   site_visits.description from site_visits where site_visits_id=:site_visits_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':site_visits_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['description'];
        echo $field;
    } function get_chosen_site_visits_account($id) {
        
        $db = new dbconnection();
        $sql = "select   site_visits.account from site_visits where site_visits_id=:site_visits_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':site_visits_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    } function get_chosen_site_visits_activity_date($id) {
        
        $db = new dbconnection();
        $sql = "select   site_visits.activity_date from site_visits where site_visits_id=:site_visits_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':site_visits_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['activity_date'];
        echo $field;
    }

 function All_site_visits() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  site_visits_id   from site_visits";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_site_visits() {
        $con = new dbconnection();
        $sql = "select site_visits.site_visits_id from site_visits
                    order by site_visits.site_visits_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['site_visits_id'];
        return $first_rec;
    }
 function get_last_site_visits() {
        $con = new dbconnection();
        $sql = "select site_visits.site_visits_id from site_visits
                    order by site_visits.site_visits_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['site_visits_id'];
        return $first_rec;
    }
function list_pub_comments($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from pub_comments";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> pub_comments </td>
<td> Profile </td><td> Message </td><td> Date </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['pub_comments_id']; ?>
</td>
<td class="profile_id_cols pub_comments " title="pub_comments" >
<?php echo  $this->_e($row['profile']); ?>
</td>
<td>
<?php echo  $this->_e($row['message']); ?>
</td>
<td>
<?php echo  $this->_e($row['date']); ?>
</td>


<td>
                        <a href="#" class="pub_comments_delete_link" style="color: #000080;" data-id_delete="pub_comments_id"  data-table="
                           <?php echo $row['pub_comments_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="pub_comments_update_link" style="color: #000080;" value="
                           <?php echo $row['pub_comments_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_pub_comments_profile($id) {
        
        $db = new dbconnection();
        $sql = "select   pub_comments.profile from pub_comments where pub_comments_id=:pub_comments_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':pub_comments_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    } function get_chosen_pub_comments_message($id) {
        
        $db = new dbconnection();
        $sql = "select   pub_comments.message from pub_comments where pub_comments_id=:pub_comments_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':pub_comments_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['message'];
        echo $field;
    } function get_chosen_pub_comments_date($id) {
        
        $db = new dbconnection();
        $sql = "select   pub_comments.date from pub_comments where pub_comments_id=:pub_comments_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':pub_comments_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date'];
        echo $field;
    }

 function All_pub_comments() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  pub_comments_id   from pub_comments";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_pub_comments() {
        $con = new dbconnection();
        $sql = "select pub_comments.pub_comments_id from pub_comments
                    order by pub_comments.pub_comments_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['pub_comments_id'];
        return $first_rec;
    }
 function get_last_pub_comments() {
        $con = new dbconnection();
        $sql = "select pub_comments.pub_comments_id from pub_comments
                    order by pub_comments.pub_comments_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['pub_comments_id'];
        return $first_rec;
    }
function list_workers($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from workers";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> workers </td>
<td> Account </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['workers_id']; ?>
</td>
<td class="account_id_cols workers " title="workers" >
<?php echo  $this->_e($row['account']); ?>
</td>


<td>
                        <a href="#" class="workers_delete_link" style="color: #000080;" data-id_delete="workers_id"  data-table="
                           <?php echo $row['workers_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="workers_update_link" style="color: #000080;" value="
                           <?php echo $row['workers_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_workers_account($id) {
        
        $db = new dbconnection();
        $sql = "select   workers.account from workers where workers_id=:workers_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':workers_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

 function All_workers() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  workers_id   from workers";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_workers() {
        $con = new dbconnection();
        $sql = "select workers.workers_id from workers
                    order by workers.workers_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['workers_id'];
        return $first_rec;
    }
 function get_last_workers() {
        $con = new dbconnection();
        $sql = "select workers.workers_id from workers
                    order by workers.workers_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['workers_id'];
        return $first_rec;
    }
function list_cell($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from cell";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> cell </td>
<td> Sector </td><td> Entry Date </td><td> User </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['cell_id']; ?>
</td>
<td class="sector_id_cols cell " title="cell" >
<?php echo  $this->_e($row['sector']); ?>
</td>
<td>
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['User']); ?>
</td>


<td>
                        <a href="#" class="cell_delete_link" style="color: #000080;" data-id_delete="cell_id"  data-table="
                           <?php echo $row['cell_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="cell_update_link" style="color: #000080;" value="
                           <?php echo $row['cell_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_cell_sector($id) {
        
        $db = new dbconnection();
        $sql = "select   cell.sector from cell where cell_id=:cell_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':cell_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['sector'];
        echo $field;
    } function get_chosen_cell_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   cell.entry_date from cell where cell_id=:cell_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':cell_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_cell_User($id) {
        
        $db = new dbconnection();
        $sql = "select   cell.User from cell where cell_id=:cell_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':cell_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    }

 function All_cell() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  cell_id   from cell";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_cell() {
        $con = new dbconnection();
        $sql = "select cell.cell_id from cell
                    order by cell.cell_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['cell_id'];
        return $first_rec;
    }
 function get_last_cell() {
        $con = new dbconnection();
        $sql = "select cell.cell_id from cell
                    order by cell.cell_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['cell_id'];
        return $first_rec;
    }
function list_o_schedule($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from o_schedule";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> o_schedule </td>
<td> Entry Date </td><td> User </td><td> Start time </td><td> End time </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['o_schedule_id']; ?>
</td>
<td class="entry_date_id_cols o_schedule " title="o_schedule" >
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['User']); ?>
</td>
<td>
<?php echo  $this->_e($row['start_time']); ?>
</td>
<td>
<?php echo  $this->_e($row['end_time']); ?>
</td>


<td>
                        <a href="#" class="o_schedule_delete_link" style="color: #000080;" data-id_delete="o_schedule_id"  data-table="
                           <?php echo $row['o_schedule_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="o_schedule_update_link" style="color: #000080;" value="
                           <?php echo $row['o_schedule_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_o_schedule_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   o_schedule.entry_date from o_schedule where o_schedule_id=:o_schedule_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':o_schedule_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_o_schedule_User($id) {
        
        $db = new dbconnection();
        $sql = "select   o_schedule.User from o_schedule where o_schedule_id=:o_schedule_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':o_schedule_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    } function get_chosen_o_schedule_start_time($id) {
        
        $db = new dbconnection();
        $sql = "select   o_schedule.start_time from o_schedule where o_schedule_id=:o_schedule_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':o_schedule_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['start_time'];
        echo $field;
    } function get_chosen_o_schedule_end_time($id) {
        
        $db = new dbconnection();
        $sql = "select   o_schedule.end_time from o_schedule where o_schedule_id=:o_schedule_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':o_schedule_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['end_time'];
        echo $field;
    }

 function All_o_schedule() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  o_schedule_id   from o_schedule";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_o_schedule() {
        $con = new dbconnection();
        $sql = "select o_schedule.o_schedule_id from o_schedule
                    order by o_schedule.o_schedule_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['o_schedule_id'];
        return $first_rec;
    }
 function get_last_o_schedule() {
        $con = new dbconnection();
        $sql = "select o_schedule.o_schedule_id from o_schedule
                    order by o_schedule.o_schedule_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['o_schedule_id'];
        return $first_rec;
    }
function list_o_worker_schedule($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from o_worker_schedule";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> o_worker_schedule </td>
<td> Entry Date </td><td> User </td><td> schedule </td><td> Worker </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['o_worker_schedule_id']; ?>
</td>
<td class="entry_date_id_cols o_worker_schedule " title="o_worker_schedule" >
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['User']); ?>
</td>
<td>
<?php echo  $this->_e($row['schedule']); ?>
</td>
<td>
<?php echo  $this->_e($row['worker']); ?>
</td>


<td>
                        <a href="#" class="o_worker_schedule_delete_link" style="color: #000080;" data-id_delete="o_worker_schedule_id"  data-table="
                           <?php echo $row['o_worker_schedule_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="o_worker_schedule_update_link" style="color: #000080;" value="
                           <?php echo $row['o_worker_schedule_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_o_worker_schedule_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   o_worker_schedule.entry_date from o_worker_schedule where o_worker_schedule_id=:o_worker_schedule_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':o_worker_schedule_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_o_worker_schedule_User($id) {
        
        $db = new dbconnection();
        $sql = "select   o_worker_schedule.User from o_worker_schedule where o_worker_schedule_id=:o_worker_schedule_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':o_worker_schedule_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    } function get_chosen_o_worker_schedule_schedule($id) {
        
        $db = new dbconnection();
        $sql = "select   o_worker_schedule.schedule from o_worker_schedule where o_worker_schedule_id=:o_worker_schedule_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':o_worker_schedule_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['schedule'];
        echo $field;
    } function get_chosen_o_worker_schedule_worker($id) {
        
        $db = new dbconnection();
        $sql = "select   o_worker_schedule.worker from o_worker_schedule where o_worker_schedule_id=:o_worker_schedule_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':o_worker_schedule_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['worker'];
        echo $field;
    }

 function All_o_worker_schedule() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  o_worker_schedule_id   from o_worker_schedule";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_o_worker_schedule() {
        $con = new dbconnection();
        $sql = "select o_worker_schedule.o_worker_schedule_id from o_worker_schedule
                    order by o_worker_schedule.o_worker_schedule_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['o_worker_schedule_id'];
        return $first_rec;
    }
 function get_last_o_worker_schedule() {
        $con = new dbconnection();
        $sql = "select o_worker_schedule.o_worker_schedule_id from o_worker_schedule
                    order by o_worker_schedule.o_worker_schedule_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['o_worker_schedule_id'];
        return $first_rec;
    }
function list_request($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from request";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> request </td>
<td> Entry Date </td><td> User </td><td> user </td><td> Message </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['request_id']; ?>
</td>
<td class="entry_date_id_cols request " title="request" >
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['User']); ?>
</td>
<td>
<?php echo  $this->_e($row['user']); ?>
</td>
<td>
<?php echo  $this->_e($row['cell']); ?>
</td>


<td>
                        <a href="#" class="request_delete_link" style="color: #000080;" data-id_delete="request_id"  data-table="
                           <?php echo $row['request_id']; ?>">Delete</a>
                    </td>
<td>
                        <a href="#" class="request_update_link" style="color: #000080;" value="
                           <?php echo $row['request_id']; ?>">Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_request_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   request.entry_date from request where request_id=:request_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':request_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_request_User($id) {
        
        $db = new dbconnection();
        $sql = "select   request.User from request where request_id=:request_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':request_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    } function get_chosen_request_user($id) {
        
        $db = new dbconnection();
        $sql = "select   request.user from request where request_id=:request_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':request_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['user'];
        echo $field;
    } function get_chosen_request_cell($id) {
        
        $db = new dbconnection();
        $sql = "select   request.cell from request where request_id=:request_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':request_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['cell'];
        echo $field;
    }

 function All_request() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  request_id   from request";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_request() {
        $con = new dbconnection();
        $sql = "select request.request_id from request
                    order by request.request_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['request_id'];
        return $first_rec;
    }
 function get_last_request() {
        $con = new dbconnection();
        $sql = "select request.request_id from request
                    order by request.request_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['request_id'];
        return $first_rec;
    }
 function get_account_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account_category.account_category_id,   account_category.name from account_category";
        ?>
        <select class="textbox cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_image_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_cell_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select cell.cell_id,   cell.name from cell";
        ?>
        <select class="textbox cbo_cell"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['cell_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_cell_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select cell.cell_id,   cell.name from cell";
        ?>
        <select class="textbox cbo_cell"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['cell_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_visit_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select visit.visit_id,   visit.name from visit";
        ?>
        <select class="textbox cbo_visit"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['visit_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_comment_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select comment.comment_id,   comment.name from comment";
        ?>
        <select class="textbox cbo_comment"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['comment_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_schedule_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select schedule.schedule_id,   schedule.name from schedule";
        ?>
        <select class="textbox cbo_schedule"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['schedule_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_worker_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select worker.worker_id,   worker.name from worker";
        ?>
        <select class="textbox cbo_worker"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['worker_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_user_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select user.user_id,   user.name from user";
        ?>
        <select class="textbox cbo_user"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }


 function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }
}

