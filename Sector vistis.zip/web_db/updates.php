<?php

require_once 'connection.php';
class updates{

 function update_account( $account_category, $date_created, $profile, $username, $password, $is_online, $position,$account_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ?, position= ? WHERE account_id=?");
$stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online, $position ,$account_id ));

}
 function update_account_category( $name,$account_category_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
$stmt->execute(array($name ,$account_category_id ));

}
 function update_profile( $dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $entry_date, $User,$profile_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ?, entry_date= ?, User= ? WHERE profile_id=?");
$stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $entry_date, $User ,$profile_id ));

}
 function update_image( $path,$image_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE image set 
path= ? WHERE image_id=?");
$stmt->execute(array($path ,$image_id ));

}
 function update_schedule_cell( $account, $cell, $day, $time,$schedule_cell_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE schedule_cell set 
account= ?, cell= ?, day= ?, time= ? WHERE schedule_cell_id=?");
$stmt->execute(array($account, $cell, $day, $time ,$schedule_cell_id ));

}
 function update_niboye_schedule( $sc_time,$niboye_schedule_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE niboye_schedule set 
sc_time= ? WHERE niboye_schedule_id=?");
$stmt->execute(array($sc_time ,$niboye_schedule_id ));

}
 function update_cell_worker( $account, $cell, $position,$cell_worker_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cell_worker set 
account= ?, cell= ?, position= ? WHERE cell_worker_id=?");
$stmt->execute(array($account, $cell, $position ,$cell_worker_id ));

}
 function update_niboye_worker( $account, $position,$niboye_worker_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE niboye_worker set 
account= ?, position= ? WHERE niboye_worker_id=?");
$stmt->execute(array($account, $position ,$niboye_worker_id ));

}
 function update_comments( $mesasge, $date, $account, $visit, $entry_date, $User,$comments_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE comments set 
mesasge= ?, date= ?, account= ?, visit= ?, entry_date= ?, User= ? WHERE comments_id=?");
$stmt->execute(array($mesasge, $date, $account, $visit, $entry_date, $User ,$comments_id ));

}
 function update_com_replies( $comment, $message, $date, $account,$com_replies_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE com_replies set 
comment= ?, message= ?, date= ?, account= ? WHERE com_replies_id=?");
$stmt->execute(array($comment, $message, $date, $account ,$com_replies_id ));

}
 function update_site_visits( $date, $activity, $description, $account, $activity_date,$site_visits_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE site_visits set 
date= ?, activity= ?, description= ?, account= ?, activity_date= ? WHERE site_visits_id=?");
$stmt->execute(array($date, $activity, $description, $account, $activity_date ,$site_visits_id ));

}
 function update_pub_comments( $profile, $message, $date,$pub_comments_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE pub_comments set 
profile= ?, message= ?, date= ? WHERE pub_comments_id=?");
$stmt->execute(array($profile, $message, $date ,$pub_comments_id ));

}
 function update_workers( $account,$workers_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE workers set 
account= ? WHERE workers_id=?");
$stmt->execute(array($account ,$workers_id ));

}
 function update_cell( $sector, $entry_date, $User,$cell_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cell set 
sector= ?, entry_date= ?, User= ? WHERE cell_id=?");
$stmt->execute(array($sector, $entry_date, $User ,$cell_id ));

}
 function update_o_schedule( $entry_date, $User, $start_time, $end_time,$o_schedule_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE o_schedule set 
entry_date= ?, User= ?, start_time= ?, end_time= ? WHERE o_schedule_id=?");
$stmt->execute(array($entry_date, $User, $start_time, $end_time ,$o_schedule_id ));

}
 function update_o_worker_schedule( $entry_date, $User, $schedule, $worker,$o_worker_schedule_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE o_worker_schedule set 
entry_date= ?, User= ?, schedule= ?, worker= ? WHERE o_worker_schedule_id=?");
$stmt->execute(array($entry_date, $User, $schedule, $worker ,$o_worker_schedule_id ));

}
 function update_request( $entry_date, $User, $user, $cell,$request_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE request set 
entry_date= ?, User= ?, user= ?, cell= ? WHERE request_id=?");
$stmt->execute(array($entry_date, $User, $user, $cell ,$request_id ));

}

}

