
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account_category`     int(11)   
,`date_created`     Date 
, `profile`     int(11)   
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`is_online`     VARCHAR(60) 
,`position`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`dob`     Date 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`telephone_number`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`residence`     VARCHAR(60) 
, `image`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 

,PRIMARY KEY (`image_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `schedule_cell`
--

CREATE TABLE IF NOT EXISTS `schedule_cell` (
`schedule_cell_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   
, `cell`     int(11)   
,`day`     VARCHAR(60) 
,`time`     VARCHAR(60) 

,PRIMARY KEY (`schedule_cell_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `niboye_schedule`
--

CREATE TABLE IF NOT EXISTS `niboye_schedule` (
`niboye_schedule_id`     int(11) NOT NULL AUTO_INCREMENT 
,`sc_time`     VARCHAR(60) 

,PRIMARY KEY (`niboye_schedule_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cell_worker`
--

CREATE TABLE IF NOT EXISTS `cell_worker` (
`cell_worker_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   
, `cell`     int(11)   
,`position`     VARCHAR(60) 

,PRIMARY KEY (`cell_worker_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `niboye_worker`
--

CREATE TABLE IF NOT EXISTS `niboye_worker` (
`niboye_worker_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   
,`position`     VARCHAR(60) 

,PRIMARY KEY (`niboye_worker_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
`comments_id`     int(11) NOT NULL AUTO_INCREMENT 
,`mesasge`     VARCHAR(60) 
,`date`     Date 
, `account`     int(11)   
, `visit`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`comments_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `com_replies`
--

CREATE TABLE IF NOT EXISTS `com_replies` (
`com_replies_id`     int(11) NOT NULL AUTO_INCREMENT 
, `comment`     int(11)   
,`message`     VARCHAR(60) 
,`date`     Date 
, `account`     int(11)   

,PRIMARY KEY (`com_replies_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `site_visits`
--

CREATE TABLE IF NOT EXISTS `site_visits` (
`site_visits_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date`     Date 
,`activity`     VARCHAR(60) 
,`description`     VARCHAR(60) 
, `account`     int(11)   
,`activity_date`     Date 

,PRIMARY KEY (`site_visits_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `pub_comments`
--

CREATE TABLE IF NOT EXISTS `pub_comments` (
`pub_comments_id`     int(11) NOT NULL AUTO_INCREMENT 
, `profile`     int(11)   
,`message`     VARCHAR(60) 
,`date`     Date 

,PRIMARY KEY (`pub_comments_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `workers`
--

CREATE TABLE IF NOT EXISTS `workers` (
`workers_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   

,PRIMARY KEY (`workers_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cell`
--

CREATE TABLE IF NOT EXISTS `cell` (
`cell_id`     int(11) NOT NULL AUTO_INCREMENT 
,`sector`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`cell_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `o_schedule`
--

CREATE TABLE IF NOT EXISTS `o_schedule` (
`o_schedule_id`     int(11) NOT NULL AUTO_INCREMENT 
,`entry_date`     Date 
,`User`     VARCHAR(60) 
,`start_time`     VARCHAR(60) 
,`end_time`     VARCHAR(60) 

,PRIMARY KEY (`o_schedule_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `o_worker_schedule`
--

CREATE TABLE IF NOT EXISTS `o_worker_schedule` (
`o_worker_schedule_id`     int(11) NOT NULL AUTO_INCREMENT 
,`entry_date`     Date 
,`User`     VARCHAR(60) 
, `schedule`     int(11)   
, `worker`     int(11)   

,PRIMARY KEY (`o_worker_schedule_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `request`
--

CREATE TABLE IF NOT EXISTS `request` (
`request_id`     int(11) NOT NULL AUTO_INCREMENT 
,`entry_date`     Date 
,`User`     VARCHAR(60) 
, `user`     int(11)   
,`cell`     VARCHAR(60) 

,PRIMARY KEY (`request_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

