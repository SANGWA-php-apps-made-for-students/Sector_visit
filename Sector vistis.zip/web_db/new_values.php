<?php 
class new_values{

 function new_account(  $account_category, $date_created, $profile, $username, $password, $is_online, $position){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online,  :position)");$stm->execute(array(':account_id'=>0,':account_category'=>$account_category, ':date_created'=>$date_created, ':profile'=>$profile, ':username'=>$username, ':password'=>$password, ':is_online'=>$is_online, ':position'=>$position
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_account_category(  $name){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into account_category values(:account_category_id, :name)");$stm->execute(array(':account_category_id'=>0,':name'=>$name
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_profile(  $dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $entry_date, $User){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image,  :entry_date,  :User)");$stm->execute(array(':profile_id'=>0,':dob'=>$dob, ':name'=>$name, ':last_name'=>$last_name, ':gender'=>$gender, ':telephone_number'=>$telephone_number, ':email'=>$email, ':residence'=>$residence, ':image'=>$image, ':entry_date'=>$entry_date, ':User'=>$User
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_image(  $path){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into image values(:image_id, :path)");$stm->execute(array(':image_id'=>0,':path'=>$path
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_schedule_cell(  $account, $cell, $day, $time){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into schedule_cell values(:schedule_cell_id, :account,  :cell,  :day,  :time)");$stm->execute(array(':schedule_cell_id'=>0,':account'=>$account, ':cell'=>$cell, ':day'=>$day, ':time'=>$time
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_niboye_schedule(  $sc_time){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into niboye_schedule values(:niboye_schedule_id, :sc_time)");$stm->execute(array(':niboye_schedule_id'=>0,':sc_time'=>$sc_time
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_cell_worker(  $account, $cell, $position){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into cell_worker values(:cell_worker_id, :account,  :cell,  :position)");$stm->execute(array(':cell_worker_id'=>0,':account'=>$account, ':cell'=>$cell, ':position'=>$position
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_niboye_worker(  $account, $position){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into niboye_worker values(:niboye_worker_id, :account,  :position)");$stm->execute(array(':niboye_worker_id'=>0,':account'=>$account, ':position'=>$position
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_comments(  $mesasge, $date, $account, $visit, $entry_date, $User){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into comments values(:comments_id, :mesasge,  :date,  :account,  :visit,  :entry_date,  :User)");$stm->execute(array(':comments_id'=>0,':mesasge'=>$mesasge, ':date'=>$date, ':account'=>$account, ':visit'=>$visit, ':entry_date'=>$entry_date, ':User'=>$User
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_com_replies(  $comment, $message, $date, $account){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into com_replies values(:com_replies_id, :comment,  :message,  :date,  :account)");$stm->execute(array(':com_replies_id'=>0,':comment'=>$comment, ':message'=>$message, ':date'=>$date, ':account'=>$account
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_site_visits(  $date, $activity, $description, $account, $activity_date){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into site_visits values(:site_visits_id, :date,  :activity,  :description,  :account,  :activity_date)");$stm->execute(array(':site_visits_id'=>0,':date'=>$date, ':activity'=>$activity, ':description'=>$description, ':account'=>$account, ':activity_date'=>$activity_date
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_pub_comments(  $profile, $message, $date){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into pub_comments values(:pub_comments_id, :profile,  :message,  :date)");$stm->execute(array(':pub_comments_id'=>0,':profile'=>$profile, ':message'=>$message, ':date'=>$date
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_workers(  $account){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into workers values(:workers_id, :account)");$stm->execute(array(':workers_id'=>0,':account'=>$account
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_cell(  $sector, $entry_date, $User){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into cell values(:cell_id, :sector,  :entry_date,  :User)");$stm->execute(array(':cell_id'=>0,':sector'=>$sector, ':entry_date'=>$entry_date, ':User'=>$User
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_o_schedule(  $entry_date, $User, $start_time, $end_time){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into o_schedule values(:o_schedule_id, :entry_date,  :User,  :start_time,  :end_time)");$stm->execute(array(':o_schedule_id'=>0,':entry_date'=>$entry_date, ':User'=>$User, ':start_time'=>$start_time, ':end_time'=>$end_time
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_o_worker_schedule(  $entry_date, $User, $schedule, $worker){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into o_worker_schedule values(:o_worker_schedule_id, :entry_date,  :User,  :schedule,  :worker)");$stm->execute(array(':o_worker_schedule_id'=>0,':entry_date'=>$entry_date, ':User'=>$User, ':schedule'=>$schedule, ':worker'=>$worker
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_request(  $entry_date, $User, $user, $cell){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into request values(:request_id, :entry_date,  :User,  :user,  :cell)");$stm->execute(array(':request_id'=>0,':entry_date'=>$entry_date, ':User'=>$User, ':user'=>$user, ':cell'=>$cell
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

}

 } 
