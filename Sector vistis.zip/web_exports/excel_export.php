 if (filter_has_var(INPUT_POST,'account')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from account";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td>Position</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['account_category'].'</td>
                 <td>'.$row['date_created'].'</td>
                 <td>'.$row['profile'].'</td>
                 <td>'.$row['username'].'</td>
                 <td>'.$row['password'].'</td>
                 <td>'.$row['is_online'].'</td>
                 <td>'.$row['position'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=account.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'account_category')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from account_category";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td></td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['name'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=account_category.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'profile')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from profile";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
               <td>Entry Date</td>
               <td>User</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['dob'].'</td>
                 <td>'.$row['name'].'</td>
                 <td>'.$row['last_name'].'</td>
                 <td>'.$row['gender'].'</td>
                 <td>'.$row['telephone_number'].'</td>
                 <td>'.$row['email'].'</td>
                 <td>'.$row['residence'].'</td>
                 <td>'.$row['image'].'</td>
                 <td>'.$row['entry_date'].'</td>
                 <td>'.$row['User'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=profile.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'image')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from image";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td></td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['path'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=image.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'schedule_cell')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from schedule_cell";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>User</td>
               <td>Cell</td>
               <td>Day</td>
               <td>Time</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['account'].'</td>
                 <td>'.$row['cell'].'</td>
                 <td>'.$row['day'].'</td>
                 <td>'.$row['time'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=schedule_cell.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'niboye_schedule')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from niboye_schedule";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Schedule Time</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['sc_time'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=niboye_schedule.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'cell_worker')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cell_worker";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>User</td>
               <td>Cell</td>
               <td>Position</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['account'].'</td>
                 <td>'.$row['cell'].'</td>
                 <td>'.$row['position'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=cell_worker.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'niboye_worker')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from niboye_worker";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Account</td>
               <td>Position</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['account'].'</td>
                 <td>'.$row['position'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=niboye_worker.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'comments')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from comments";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Message</td>
               <td>Date</td>
               <td>User</td>
               <td>Visit</td>
               <td>Entry Date</td>
               <td>User</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['mesasge'].'</td>
                 <td>'.$row['date'].'</td>
                 <td>'.$row['account'].'</td>
                 <td>'.$row['visit'].'</td>
                 <td>'.$row['entry_date'].'</td>
                 <td>'.$row['User'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=comments.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'com_replies')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from com_replies";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Comment</td>
               <td>Message</td>
               <td>Date</td>
               <td>User</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['comment'].'</td>
                 <td>'.$row['message'].'</td>
                 <td>'.$row['date'].'</td>
                 <td>'.$row['account'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=com_replies.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'site_visits')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from site_visits";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Date</td>
               <td>Activity</td>
               <td>Description</td>
               <td>Account</td>
               <td>Activity Date</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['date'].'</td>
                 <td>'.$row['activity'].'</td>
                 <td>'.$row['description'].'</td>
                 <td>'.$row['account'].'</td>
                 <td>'.$row['activity_date'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=site_visits.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'pub_comments')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from pub_comments";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Profile</td>
               <td>Message</td>
               <td>Date</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['profile'].'</td>
                 <td>'.$row['message'].'</td>
                 <td>'.$row['date'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=pub_comments.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'workers')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from workers";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Account</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['account'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=workers.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'cell')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cell";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Sector</td>
               <td>Entry Date</td>
               <td>User</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['sector'].'</td>
                 <td>'.$row['entry_date'].'</td>
                 <td>'.$row['User'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=cell.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'o_schedule')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from o_schedule";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Entry Date</td>
               <td>User</td>
               <td>Start time</td>
               <td>End time</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['entry_date'].'</td>
                 <td>'.$row['User'].'</td>
                 <td>'.$row['start_time'].'</td>
                 <td>'.$row['end_time'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=o_schedule.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'o_worker_schedule')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from o_worker_schedule";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Entry Date</td>
               <td>User</td>
               <td>schedule</td>
               <td>Worker</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['entry_date'].'</td>
                 <td>'.$row['User'].'</td>
                 <td>'.$row['schedule'].'</td>
                 <td>'.$row['worker'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=o_worker_schedule.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

 if (filter_has_var(INPUT_POST,'request')){
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from request";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                $output = '';
                $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Entry Date</td>
               <td>User</td>
               <td>user</td>
               <td>Message</td>
                        </tr></thead>
               ';

                while ($row = $stmt->fetch()) {
                    $output .= '<tr> 

                 <td>'.$row['entry_date'].'</td>
                 <td>'.$row['User'].'</td>
                 <td>'.$row['user'].'</td>
                 <td>'.$row['cell'].'</td>

                        </tr>';
                }

                $output .= '</table>';
                header("Content-Type: vnd.ms-excel");
                header("Content-Disposition:attachment; filename=request.xls");
                header("Pragma: no-cache");
                header("Expires: 0");
                echo $output;
            }

