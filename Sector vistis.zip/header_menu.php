<div class="parts  eighty_centered ">            <div class="parts  no_paddin_shade_no_Border xxx_titles">
                sector activities
            </div>
</div>        <div class="parts menu eighty_centered">
<a href="new_account.php">account</a>
<a href="new_account_category.php">account_category</a>
<a href="new_profile.php">profile</a>
<a href="new_image.php">image</a>
<a href="new_schedule_cell.php">schedule_cell</a>
<a href="new_niboye_schedule.php">niboye_schedule</a>
<a href="new_cell_worker.php">cell_worker</a>
<a href="new_niboye_worker.php">niboye_worker</a>
<a href="new_comments.php">comments</a>
<a href="new_com_replies.php">com_replies</a>
<a href="new_site_visits.php">site_visits</a>
<a href="new_pub_comments.php">pub_comments</a>
<a href="new_workers.php">workers</a>
<a href="new_cell.php">cell</a>
<a href="new_o_schedule.php">o_schedule</a>
<a href="new_o_worker_schedule.php">o_worker_schedule</a>
<a href="new_request.php">request</a>

  <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href="login.php">Login</a>
            </div>
       </div>
